-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema addressesdb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema addressesdb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `addressesdb` DEFAULT CHARACTER SET utf8 ;
USE `addressesdb` ;

-- -----------------------------------------------------
-- Table `addressesdb`.`municipalities`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `addressesdb`.`municipalities` (
  `municipalities_id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `postal_code` INT(10) NULL DEFAULT NULL,
  `populated_area_id` INT(11) NOT NULL,
  PRIMARY KEY (`municipalities_id`),
  UNIQUE INDEX `municipalities_id_UNIQUE` (`municipalities_id` ASC),
  INDEX `FK_municipalities_populated_area_types_idx` (`populated_area_id` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 16
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `addressesdb`.`streets`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `addressesdb`.`streets` (
  `streets_id` INT(11) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `municipalities_id` INT(11) NOT NULL,
  PRIMARY KEY (`streets_id`),
  UNIQUE INDEX `streets_id_UNIQUE` (`streets_id` ASC),
  INDEX `FK_streets_municipalities_idx` (`municipalities_id` ASC),
  CONSTRAINT `FK_streets_municipalities`
    FOREIGN KEY (`municipalities_id`)
    REFERENCES `addressesdb`.`municipalities` (`municipalities_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `addressesdb`.`addresses`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `addressesdb`.`addresses` (
  `addresses_id` INT(11) NOT NULL AUTO_INCREMENT,
  `street_id` INT(11) NOT NULL,
  `number` INT(10) NOT NULL,
  `apartmentNo` INT(10) NOT NULL,
  PRIMARY KEY (`addresses_id`),
  UNIQUE INDEX `addresses_id_UNIQUE` (`addresses_id` ASC),
  INDEX `FK_addresses_streets_idx` (`street_id` ASC),
  CONSTRAINT `FK_addresses_streets`
    FOREIGN KEY (`street_id`)
    REFERENCES `addressesdb`.`streets` (`streets_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 22
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `addressesdb`.`countries`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `addressesdb`.`countries` (
  `country_id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`country_id`),
  UNIQUE INDEX `country_id_UNIQUE` (`country_id` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `addressesdb`.`regions`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `addressesdb`.`regions` (
  `regions_id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `country_id` INT(11) NOT NULL,
  PRIMARY KEY (`regions_id`),
  UNIQUE INDEX `regions_id_UNIQUE` (`regions_id` ASC),
  INDEX `FK_regions_countries_idx` (`country_id` ASC),
  CONSTRAINT `FK_regions_countries`
    FOREIGN KEY (`country_id`)
    REFERENCES `addressesdb`.`countries` (`country_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 7
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `addressesdb`.`populated_areas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `addressesdb`.`populated_areas` (
  `populated_areas_id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `regions_id` INT(11) NOT NULL,
  `populated_area_types_id` INT(11) NOT NULL,
  PRIMARY KEY (`populated_areas_id`),
  UNIQUE INDEX `populated_areas_id_UNIQUE` (`populated_areas_id` ASC),
  INDEX `FK_populated_areas_regions_idx` (`regions_id` ASC),
  INDEX `FK_populated_areas_regions_idx1` (`populated_area_types_id` ASC),
  CONSTRAINT `FK_populated_areas_regions`
    FOREIGN KEY (`regions_id`)
    REFERENCES `addressesdb`.`regions` (`regions_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 13
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `addressesdb`.`populated_area_types`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `addressesdb`.`populated_area_types` (
  `populated_area_types_id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`populated_area_types_id`),
  UNIQUE INDEX `populated_area_types_id_UNIQUE` (`populated_area_types_id` ASC),
  CONSTRAINT `FK_populated_areas_type_populated_area`
    FOREIGN KEY (`populated_area_types_id`)
    REFERENCES `addressesdb`.`populated_areas` (`populated_area_types_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
